﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestProject1;
using System;
using Example;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {// arrange
            string password = "9";
            int expected = 0;
            // act
            int actual = Class1.GetPasswordStrength(password);
            // assert
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestMethod2()
        {// arrange
            string password = "nine";
            int expected = 1;
            // act
            int actual = Class1.GetPasswordStrength(password);
            // assert
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestMethod3()
        {// arrange
            string password = "18s";
            int expected = 2;
            // act
            int actual = Class1.GetPasswordStrength(password);
            // assert
            Assert.AreEqual(expected, actual);

        }
    }
}
