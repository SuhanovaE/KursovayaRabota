﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JewelryRepair.Classes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTypeJewel.xaml
    /// </summary>
    public partial class PageTypeJewel : Page
    {
        private static JewelryShopEntities _context = new JewelryShopEntities();
        public PageTypeJewel()
        {
            InitializeComponent();
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();

            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {

        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
