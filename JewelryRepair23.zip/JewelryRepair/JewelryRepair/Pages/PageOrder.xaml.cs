﻿using JewelryRepair.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;


namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();

                CmbFiltrDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
                CmbFiltrDiscount.SelectedValuePath = "id_discount";
                CmbFiltrDiscount.DisplayMemberPath = "discount1";

                CmbFiltrService.ItemsSource = JewelryShopEntities.GetContext().Service.ToList();
                CmbFiltrService.SelectedValuePath = "id_service";
                CmbFiltrService.DisplayMemberPath = "name";
            }
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.Clients.lastname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.OrderBy(x => x.date_adoption).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.OrderByDescending(x => x.date_adoption).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            CmbFiltrDiscount.SelectedIndex = -1;
            CmbFiltrPrice.SelectedIndex = -1;
            CmbFiltrService.SelectedIndex = -1;
            RbUp.IsChecked= false;
            RbDown.IsChecked= false;
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var orderForRemoving = DGridOrder.SelectedItems.Cast<Order>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {orderForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Order.RemoveRange(orderForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder((sender as Button).DataContext as Order));
        }

        private void CmbFiltrPrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltrPrice.SelectedIndex == 0)
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                    x.price >= 0 && x.price <= 1500).ToList();
            }
            else
                if (CmbFiltrPrice.SelectedIndex == 1)
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                    x.price >= 1501 && x.price <= 2999).ToList();
            }
            else
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                   x.price >= 3000).ToList();
            }
        }

        private void CmbFiltrDiscount_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrDiscount.SelectedIndex + 1;
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.fk_discount == id).ToList();
        }

        private void CmbFiltrService_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrService.SelectedIndex + 1;
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.fk_service == id).ToList();
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            // объект Excel
            var app = new Excel.Application();

            // книга
            Excel.Workbook wb = app.Workbooks.Add();

            // лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 5;
            // ячейки
            // 1 - номер столбца 
            // 2 - номер строки
            worksheet.Cells[3][indexRows] = "Номер";
            worksheet.Cells[4][indexRows] = "Поступление";
            worksheet.Cells[5][indexRows] = "Выдача";
            worksheet.Cells[6][indexRows] = "Клиент";
            worksheet.Cells[7][indexRows] = "Вес изделия";
            worksheet.Cells[8][indexRows] = "Услуга";
            worksheet.Cells[9][indexRows] = "Цена";
            worksheet.Cells[10][indexRows] = "Скидка (в %)";

            var printItems = DGridOrder.Items;
            Excel.Range Bold = worksheet.Range[worksheet.Cells[3][indexRows], worksheet.Cells[10][indexRows]];
            
            Bold.Style.Font.Name = "Times New Roman";
            Bold.Font.Bold = true;
            Excel.Range Borders = worksheet.Range[worksheet.Cells[3][indexRows], worksheet.Cells[10][indexRows]];
            Borders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            Borders.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            

            worksheet.Columns.AutoFit();

            Excel.Range DocumentRange = worksheet.Range[worksheet.Cells[6][2], worksheet.Cells[8][2]];
            DocumentRange.Merge();
            DocumentRange.Value = "Документ";
            DocumentRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            Excel.Range TitleRange = worksheet.Range[worksheet.Cells[6][3], worksheet.Cells[8][3]];
            TitleRange.Merge();   
            TitleRange.Value = "Общая прибыль за выполненные заказы за всё время работы";
            TitleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            TitleRange.Style.Font.Name = "Times New Roman";

            //цикл по данным из таблицы
            foreach (Order item in printItems)
            {
                worksheet.Cells[3][indexRows + 1] = indexRows-4;
                worksheet.Cells[4][indexRows + 1] = item.date_adoption;
                worksheet.Cells[5][indexRows + 1] = item.date_issue;
                worksheet.Cells[5][indexRows+1].ColumnWidth = 10;
                worksheet.Cells[6][indexRows + 1] = item.Clients.lastname.ToString();
                worksheet.Cells[6][indexRows].ColumnWidth = 13;
                worksheet.Cells[7][indexRows + 1] = item.Jewel.weight.Value;
                worksheet.Cells[8][indexRows + 1] = item.Service.name.ToString();
                worksheet.Cells[8][indexRows].ColumnWidth = 35;
                worksheet.Cells[9][indexRows + 1] = item.price;
                worksheet.Cells[9][indexRows].ColumnWidth = 8;
                //worksheet.Cells[9][indexRows + 1] = item.Converter("jewelry.png");
                worksheet.Cells[10][indexRows + 1] = item.Discount.discount1.ToString();
                
                indexRows++;
            }

            Excel.Range Borders1 = worksheet.Range[worksheet.Cells[3][indexRows - printItems.Count], worksheet.Cells[10][indexRows]];
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders1.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
           

            worksheet.Cells[8][indexRows + 1] = "Общая прибыль:";
            worksheet.Cells[8][indexRows + 1].Style.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
            worksheet.Cells[8][indexRows + 1].Font.Bold = true;

            worksheet.Cells[9][indexRows + 1].Formula = $"=SUM(I{indexRows}:" + $"I{indexRows - printItems.Count + 1})";
            worksheet.Cells[9][indexRows + 1].Font.Bold = true;

            Excel.Range DirectorRange = worksheet.Range[worksheet.Cells[8][indexRows + 3], worksheet.Cells[10][indexRows + 3]];
            DirectorRange.Merge();
            DirectorRange.Value = "Подпись директора _______________________";
            DirectorRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            Excel.Range AccountantRange = worksheet.Range[worksheet.Cells[8][indexRows + 5], worksheet.Cells[10][indexRows + 5]];
            AccountantRange.Merge();
            AccountantRange.Value = "Подпись бухгалтера _______________________";
            AccountantRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

            Excel.Range DateRange = worksheet.Range[worksheet.Cells[8][indexRows + 7], worksheet.Cells[10][indexRows + 7]];
            DateRange.Merge();
            DateRange.Value = "Дата «__» _______________ 20__г.";
            DateRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

            // показать Excel
            app.Visible = true;
        }
    }
}
