﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JewelryRepair.Classes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTypeJewel.xaml
    /// </summary>
    public partial class PageTypeJewel : Page
    {
        private static JewelryShopEntities _context = new JewelryShopEntities();
        public PageTypeJewel()
        {
            InitializeComponent();
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var typeForRemoving = DGridType.SelectedItems.Cast<Type>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {typeForRemoving.Count()} скидки?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Type.RemoveRange(typeForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageTypeJewel(null));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageTypeJewel((sender as Button).DataContext as Type));
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            RbUp.IsChecked = false;
            RbDown.IsChecked = false;
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.OrderByDescending(x => x.type1).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.OrderBy(x => x.type1).ToList();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridType.ItemsSource = JewelryShopEntities.GetContext().Type.Where(x => x.type1.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }
    }
}
