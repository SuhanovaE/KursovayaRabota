﻿using JewelryRepair.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageJewels.xaml
    /// </summary>
    public partial class PageJewels : Page
    {
        private static JewelryShopEntities _context = new JewelryShopEntities();
        public PageJewels()
        {
            InitializeComponent();
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.ToList();

            CmbFiltrType.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
            CmbFiltrType.SelectedValuePath = "id_type";
            CmbFiltrType.DisplayMemberPath = "type1";
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.ToList();            
            }
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void CmbFiltrType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrType.SelectedIndex + 1;
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.Where(x => x.fk_type == id).ToList();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.Where(x => x.material.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.OrderBy(x => x.weight).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.OrderByDescending(x => x.weight).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            CmbFiltrType.SelectedIndex = -1;
            RbUp.IsChecked = false;
            RbDown.IsChecked = false;
            DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageJewels((sender as Button).DataContext as Jewel));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageJewels(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var jewelForRemoving = DGridJewel.SelectedItems.Cast<Jewel>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {jewelForRemoving.Count()} изделия?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Jewel.RemoveRange(jewelForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridJewel.ItemsSource = JewelryShopEntities.GetContext().Jewel.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnWord_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnToList_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
