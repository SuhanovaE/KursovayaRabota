﻿using JewelryRepair.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDiscount.xaml
    /// </summary>
    public partial class PageDiscount : Page
    {
        private static JewelryShopEntities _context = new JewelryShopEntities();
        public PageDiscount()
        {
            InitializeComponent();
            DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
            }
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.OrderByDescending(x => x.discount1).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.OrderBy(x => x.discount1).ToList();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var discountForRemoving = DGridDiscount.SelectedItems.Cast<Discount>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {discountForRemoving.Count()} скидки?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Discount.RemoveRange(discountForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageDiscount(null));
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageDiscount((sender as Button).DataContext as Discount));
        }
    }
}
