﻿using JewelryRepair.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();

                CmbFiltrDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
                CmbFiltrDiscount.SelectedValuePath = "id_discount";
                CmbFiltrDiscount.DisplayMemberPath = "discount1";

                CmbFiltrService.ItemsSource = JewelryShopEntities.GetContext().Service.ToList();
                CmbFiltrService.SelectedValuePath = "id_service";
                CmbFiltrService.DisplayMemberPath = "name";
            }
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.Clients.lastname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.OrderBy(x => x.date_adoption).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.OrderByDescending(x => x.date_adoption).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var orderForRemoving = DGridOrder.SelectedItems.Cast<Order>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {orderForRemoving.Count()} заказа?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Order.RemoveRange(orderForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder((sender as Button).DataContext as Order));
        }

        private void CmbFiltrPrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltrPrice.SelectedIndex == 0)
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                    x.price >= 0 && x.price <= 1500).ToList();
            }
            else
                if (CmbFiltrPrice.SelectedIndex == 1)
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                    x.price >= 1501 && x.price <= 2999).ToList();
            }
            else
            {
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x =>
                   x.price >= 3000).ToList();
            }
        }

        private void CmbFiltrDiscount_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrDiscount.SelectedIndex + 1;
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.fk_discount == id).ToList();
        }

        private void CmbFiltrService_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrService.SelectedIndex + 1;
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.Where(x => x.fk_service == id).ToList();
        }
    }
}
