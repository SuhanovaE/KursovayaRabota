﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageJewels.xaml
    /// </summary>
    public partial class AddEditPageJewels : Page
    {
        private Jewel _currentJewel = new Jewel();
        public AddEditPageJewels(Jewel selectedJewel)
        {
            InitializeComponent();
            if (selectedJewel != null)
                _currentJewel = selectedJewel;
            //создаем контекст
            DataContext = _currentJewel;
            CmbTypeJewel.ItemsSource = JewelryShopEntities.GetContext().Type.ToList();
            CmbTypeJewel.SelectedValuePath = "id_type";
            CmbTypeJewel.DisplayMemberPath = "type1";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentJewel.material))
                error.AppendLine("Укажите состав");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentJewel.id_jewel == 0)
                JewelryShopEntities.GetContext().Jewel.Add(_currentJewel); //добавить в контекст
            try
            {
                JewelryShopEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новое изделие добавлено");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
