﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageTypeJewel.xaml
    /// </summary>
    public partial class AddEditPageTypeJewel : Page
    {
        private Type _currentType = new Type();
        public AddEditPageTypeJewel(Type selectedType)
        {
            InitializeComponent();            
            if (selectedType != null)
                _currentType = selectedType;
            //создаем контекст
            DataContext = _currentType;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentType.type1))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
        }
    }
}
