﻿using JewelryRepair.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : Page
    {
        public PageOrder()
        {
            InitializeComponent();
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();

            }
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageClients());
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var orderForRemoving = DGridOrder.SelectedItems.Cast<Order>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {orderForRemoving.Count()} заказа?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Order.RemoveRange(orderForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridOrder.ItemsSource = JewelryShopEntities.GetContext().Order.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageOrder((sender as Button).DataContext as Order));
        }
    }
}
