﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageOrder.xaml
    /// </summary>
    public partial class AddEditPageOrder : Page
    {
        private Order _currentOrder = new Order();

        public AddEditPageOrder(Order selectedOrder)
        {
            InitializeComponent();
            if (selectedOrder != null)
                _currentOrder = selectedOrder;
            //создаем контекст
            DataContext = _currentOrder;
            CmbClient.ItemsSource = JewelryShopEntities.GetContext().Clients.ToList();
            CmbClient.SelectedValuePath = "id_clients";
            CmbClient.DisplayMemberPath = "lastname";

            CmbWeight.ItemsSource = JewelryShopEntities.GetContext().Jewel.ToList();
            CmbWeight.SelectedValuePath = "id_jewel";
            CmbWeight.DisplayMemberPath = "weight";

            CmbService.ItemsSource = JewelryShopEntities.GetContext().Service.ToList();
            CmbService.SelectedValuePath = "id_service";
            CmbService.DisplayMemberPath = "name";

            CmbDiscount.ItemsSource = JewelryShopEntities.GetContext().Discount.ToList();
            CmbDiscount.SelectedValuePath = "id_discount";
            CmbDiscount.DisplayMemberPath = "discount1";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentOrder.date_adoption == null)
                error.AppendLine("Укажите дату поступления");
            if (_currentOrder.date_issue == null)
                error.AppendLine("Укажите дату выдачи");
            if (_currentOrder.fk_clients == null)
                error.AppendLine("Укажите фамилию клиента");
            if (_currentOrder.fk_jewel == null)
                error.AppendLine("Укажите вес изделия");
            if (_currentOrder.fk_service == null)
                error.AppendLine("Укажите услугу");
            if (_currentOrder.price == null || _currentOrder.price < 1)
                error.AppendLine("Укажите цену");
            if (_currentOrder.fk_discount == null || _currentOrder.fk_discount < 0)
                error.AppendLine("Укажите скидку");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentOrder.id_order == 0)
                JewelryShopEntities.GetContext().Order.Add(_currentOrder); //добавить в контекст
            try
            {
                JewelryShopEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый заказ добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
