﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JewelryRepair.Classes;

namespace JewelryRepair.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageClients.xaml
    /// </summary>
    public partial class PageClients : Page
    {
        private static JewelryShopEntities _context = new JewelryShopEntities();
        public PageClients()
        {
            InitializeComponent();
            DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                JewelryShopEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            RbUp.IsChecked = false;
            RbDown.IsChecked = false;
            DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.ToList();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.Where(x => x.lastname.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.OrderBy(x => x.lastname).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.OrderByDescending(x => x.lastname).ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageClients((sender as Button).DataContext as Clients));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageClients(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var clientForRemoving = DGridClient.SelectedItems.Cast<Clients>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {clientForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    JewelryShopEntities.GetContext().Clients.RemoveRange(clientForRemoving);
                    JewelryShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridClient.ItemsSource = JewelryShopEntities.GetContext().Clients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageJewels());
        }

        private void BtnTypeJewel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTypeJewel());
        }

        private void BtnDiscount_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDiscount());
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void BtnService_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageService());
        }

    }
}
